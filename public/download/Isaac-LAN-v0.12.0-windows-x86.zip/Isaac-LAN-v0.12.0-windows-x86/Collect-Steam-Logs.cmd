@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0collect_steam_logs.ps1"
set "installer_exit=%errorlevel%"
pause
exit /b %installer_exit%
