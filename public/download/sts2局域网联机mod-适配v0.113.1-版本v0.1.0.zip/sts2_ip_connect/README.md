# sts2_ip_connect

轻量级 PC 局域网 / IP 联机 Mod，适用于 **Slay the Spire 2**。

- 使用游戏原生 ENet 传输（`NetHostGameService.StartENetHost` + `ENetClientConnectionInitializer`）。
- 不替换 `NetHost` / `NetClient`，不修改游戏联机协议。
- 多人游戏界面新增独立的「局域网开房 / 局域网加入」入口，原版 Steam 创建/加入流程保持不变。
- 当前版本：**STS2 0.113.x public-beta**（在本机 0.113.1 上编译并验证）。

## 构建

```powershell
# 需要 .NET 9 SDK
.\tools\build.ps1 -Install
```

`-Install` 会把 DLL 和 manifest 安装到：

```
<Slay the Spire 2>\mods\sts2_ip_connect\
├── sts2_ip_connect.dll
└── sts2_ip_connect.json
```

可用 `STS2_GAME_DIR` 覆盖游戏目录。

## 分发

生成发布包：

```powershell
.\tools\package.ps1
# 或指定版本：.\tools\package.ps1 -Version 0.1.1 -GameVersion 0.113.1
```

输出：

```
dist\sts2_ip_connect-0.1.0-0.113.1.zip
└── sts2_ip_connect\
    ├── sts2_ip_connect.dll
    ├── sts2_ip_connect.json
    └── README.md
```

安装：把压缩包里的 `sts2_ip_connect` 文件夹解压到：

```
<Slay the Spire 2>\mods\
```

即最终路径为 `mods\sts2_ip_connect\sts2_ip_connect.dll`。卸载时删除整个 `sts2_ip_connect` 文件夹即可。

分发要点：

- 只分发 `dist\` 里的 zip，**不要**分发 `lib/`、`_refs/`、源码或游戏 DLL。
- 房主和客户端必须使用**同一游戏版本**（当前 0.113.1）和**同一 Mod 版本**。
- `affects_gameplay: true` 但 Mod 自身会从联机版本握手列表中排除，因此版本一致性需要靠发布说明约束，而不是靠游戏自动校验。
- 推荐用 GitHub Releases 挂 zip，release 标题写明支持的游戏版本；也可以上传 Nexus Mods 等站点。
- Steam 创意工坊：游戏目前只确认支持读取订阅的工坊 Mod，上传需要额外的 Steamworks UGC 工具/账号，v0.1 不做。
- 手机端不使用这个 DLL；手机端继续用启动器内置的 LAN 补丁，输入 PC 房主的 `IP:端口` 加入。

## 使用

1. 所有玩家安装同一版本的游戏和本 Mod。
2. 房主：多人模式 → **局域网开房** → 选择模式 → 把弹窗中的 `<IP>:端口` 发给其他玩家。
3. 其他玩家：多人模式 → **局域网加入** → 输入房主地址 → 加入。

界面说明：

- 没有多人存档时，原版「加载 / 放弃」两个空卡片位会被复用为「局域网开房 / 局域网加入」，保持原版四卡片布局。
- 已有多人存档时，四个原版卡片都在使用，局域网入口会以左下角紧凑按钮显示。

配置文件写在 Mod DLL 同目录的 `config.json`（玩家名 / 玩家 ID、端口、最大人数、最近地址），日志写在 `sts2_ip_connect.log`。

## v0.1 范围

- 开房：标准、每日、Dread、Blitz、自定义（新局）。
- 加入：大厅、读档大厅、运行中重连（由游戏原生 `NJoinFriendScreen.JoinGameAsync` 处理）。
- 仅保证 IPv4；IPv6 暂不支持。
- 载入已有存档后开局域网房间的独立入口暂未接入。
- 本 Mod 会把自己从联机版本握手的 Mod 列表中排除，避免与手机端兼容包或未安装本 Mod 的对端因 Mod 列表不一致被踢；其他 Mod 不受影响。
