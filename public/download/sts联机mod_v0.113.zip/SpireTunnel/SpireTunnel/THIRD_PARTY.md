# Third-party notices

SpireTunnel uses the native Slay the Spire 2 ENet and menu APIs. Its implementation was informed by the host/join and platform-identity approach in [LanSpire](https://github.com/Madlezz/LanSpire), Copyright (c) 2026 Madlezz, MIT licensed. The complete original license is included verbatim in LICENSE-LanSpire.

No LanSpire custom message serializer, mod-list bypass, update checker, gameplay synchronization timeout or disconnected-player automation is included. No TasteSteak DirectConnectIP code is included.

GodotSharp, Harmony and the game assemblies are build/runtime references supplied by the user's game installation. They are not included in the package. Slay the Spire 2 is owned by Mega Crit; SpireTunnel is an unofficial mod.
