# SpireTunnel

让《杀戮尖塔 2》通过 IP / 域名和端口加入联机房间，适合 Sakura Frp（樱花内网穿透）的 UDP 隧道。

本包按本机 **v0.113.0 public-beta** 的游戏程序集制作，发布信息为 `commit:16ac0fe3`、`main_assembly_hash:2138858832`。所有玩家应使用相同游戏构建、相同 SpireTunnel 版本和相同启用模组。游戏再次更新后应重新检查兼容性。

## 安装

1. 所有玩家退出游戏并解压安装包。
2. 在安装包目录打开 PowerShell，运行：

   ```powershell
   .\Install.ps1
   ```

   脚本会查找常见 Steam 安装位置。未找到时手动指定**游戏根目录**：

   ```powershell
   .\Install.ps1 -GameDir 'D:\steam\steamapps\common\Slay the Spire 2'
   ```

   若系统执行策略拦截这个脚本，核对脚本内容后，可仅为本次运行指定执行策略：

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1 -GameDir 'D:\steam\steamapps\common\Slay the Spire 2'
   ```

3. 从 Steam 正常启动游戏，接受游戏的模组加载提示，确认启用了 SpireTunnel。请停用旧的 DirectConnectIP、LanSpire 或其他替换联机传输的模组，避免入口冲突。

也可手动把安装包中的 `SpireTunnel` 文件夹复制到 `<游戏根目录>\mods\`。最终至少应有：

```text
mods\SpireTunnel\SpireTunnel.dll
mods\SpireTunnel\SpireTunnel.json
```

这是代码型模组，不需要额外 PCK。安装脚本检查游戏版本和构建标识；更换现有 SpireTunnel 前会先把旧文件夹移到 `<游戏根目录>\SpireTunnel-backups\`。脚本不会修改防火墙或游戏本体。

## 房主：Sakura Frp 配置

在**运行游戏的同一台电脑**上使用 Sakura Frp 启动器，新建隧道：

| 字段 | 填写内容 |
| --- | --- |
| 隧道名称 | `SpireTunnel`，也可自行命名 |
| 隧道类型 | **UDP** |
| 本地 IP | `127.0.0.1` |
| 本地端口 | `33771`；若在模组中改了监听端口，这里也要同步修改 |
| 远程端口 | 留空让节点分配，或选择节点允许且未占用的端口 |

启动隧道，并复制启动器日志给出的**连接地址**，例如 `节点域名:远程端口`。游玩期间保持游戏和隧道开启。远程端口不必是 `33771`，朋友应填写节点实际分配的端口。[Sakura Frp 内网穿透说明](https://doc.natfrp.com/basics.html)

进入游戏的多人游戏菜单，点击右上角 **IP 联机 · Sakura Frp**。打开“原版创建 / 继续游戏按钮使用 IP 房间”开关，确认监听端口并点击**保存房主设置**。关闭窗口后，使用游戏原有的**新建联机**或**继续游戏**流程开房。已经在 Steam 模式创建的房间应退出后再切换。

## 朋友加入

安装相同版本的模组后，在多人游戏菜单点击 **IP 联机 · Sakura Frp**，在“加入房间”处输入房主发来的完整地址并点击**加入**。朋友无需打开房主开关。例如：

```text
example-node.natfrp.example:41234
203.0.113.10:41234
```

这两个地址仅示意格式，不能实际连接。朋友填写的是 **Sakura 节点地址 + 远程端口**。如果没有更改端口且直接连局域网房主，可填写 `房主局域网IP:33771`。房主使用自定义端口时须同步修改 Sakura 的本地端口。

继续一局 IP 联机时，由原房主使用“继续游戏”开房，朋友再从 IP 窗口加入。模组设置中的玩家标识用于认回原来的角色，请保留自己的设置文件 `%APPDATA%\SlayTheSpire2\mods\SpireTunnel\settings.json`，不要把它复制给朋友。本安装包和安装脚本均不包含或覆盖个人设置。

## 连不上时

- 先核对双方游戏版本和构建标识、模组版本及启用模组列表，再核对房主是否已在 IP 模式开房。
- 检查 Sakura 隧道是否在线、类型是否为 UDP、本地端口是否与房主监听端口一致，朋友是否填了日志中的节点连接地址和远程端口。[Sakura 游戏隧道通用说明](https://doc.natfrp.com/game/other-games.html)
- 先用另一台局域网电脑连接 `房主局域网IP:监听端口`，确认游戏房间本身可访问；再排查穿透。若 Windows 提示防火墙访问权限，按实际网络环境允许游戏通信，不要关闭整个防火墙。
- `Test-NetConnection -Port` 检查的是 TCP，不能证明这个 UDP 游戏隧道可用。
- 对持续存在的 UDP 映射问题，可把房主监听端口、Sakura 本地端口都改成 Sakura 分配的远程端口，再重开房间和隧道。[Sakura UDP 问题说明](https://doc.natfrp.com/faq/network.html)

## 卸载或停用

退出游戏，在安装包目录运行：

```powershell
.\Uninstall.ps1 -GameDir 'D:\steam\steamapps\common\Slay the Spire 2'
```

它会把 `mods\SpireTunnel` 移入游戏根目录的 `SpireTunnel-backups`，保留文件便于恢复。也可在退出游戏后手动把该文件夹移出 `mods`。停用后游戏的存档目录规则仍由游戏管理。

## 验证状态

- 使用本机 v0.113.0 程序集完成 Release 编译：0 个警告、0 个错误。
- 地址输入的 44 项自动测试全部通过。
- 在隔离的实际 v0.113.0 游戏副本中成功加载，菜单窗口和控件尺寸检查通过。
- 两个实际游戏进程通过 127.0.0.1 UDP 完成原生握手，双方均进入两人大厅，玩家 ID 一致且没有重复加入。
- 安装、重复安装、备份替换、版本拒绝和保留文件卸载经过隔离目录测试。

尚未验证：完整一局、所有模式及续档的实际游玩、Sakura 节点到朋友电脑的公网链路。此包严格限定 v0.113.0；不能据此认为后续版本兼容。请通过 Steam 正常启动游戏。

续局请由原房主继续，朋友重新加入。游戏原版“放弃联机”对 IP 存档可能缺少历史/进度记录；此包不改写原有存档。若要保留该局记录，请先备份存档。

## 来源

- [Mega Crit 官方更新公告：v0.113.0 beta](https://steamcommunity.com/app/2868840/announcements/?l=english)
- [Sakura Frp 启动器安装和使用](https://doc.natfrp.com/launcher/usage.html)
- [Sakura Frp 官方 frpc 用户手册](https://doc.natfrp.com/frpc/manual)

本项目为独立第三方模组，与 Mega Crit、Sakura Frp 无隶属关系。
