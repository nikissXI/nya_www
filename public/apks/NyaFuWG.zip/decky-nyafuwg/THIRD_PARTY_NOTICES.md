# Third Party Notices

## WireGuard Tools

This package includes prebuilt Linux x86_64 files from Arch Linux `wireguard-tools`.

- Package: `wireguard-tools`
- Version: `1.0.20260223`
- Upstream project: https://git.zx2c4.com/wireguard-tools/
- Arch Linux package page: https://archlinux.org/packages/extra/x86_64/wireguard-tools/
- License: GPL-2.0-only

Included files:

- `bin/wg`
- `bin/wg-quick`

SHA256:

- `bin/wg`: `1E5A2936870B30CEF1A4FC74453B57C1527D7B7F619BD9DD30AA613E6D09A0EC`
- `bin/wg-quick`: `C557B7D6DC9D9CB7D29026666686CDBC6B92804D9232AC8BAE1B58FABD4DCF6D`

The GPL-2.0-only license text is included at `LICENSES/GPL-2.0-only.txt`.
