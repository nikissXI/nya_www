# NyaFu WG

NyaFu WG 是给 Steam Deck 游戏模式使用的喵服 WireGuard 连接器。插件不复刻喵服网页，不处理房间状态，不保存喵服账号密码；喵服网页负责登录、选节点、创建房间、加入房间和下载隧道配置，插件负责在 Steam Deck 上导入配置、连接/断开 WireGuard，并保持隧道在线。

## 当前边界

插件负责：

- 打开喵服网页和配置教程。
- 扫描下载目录、文档、桌面和外接盘里的 WireGuard `.conf` 配置。
- 验证并导入喵服隧道配置。
- 使用 `wg-quick up/down` 启动或停止 WireGuard。
- 显示喵服网络状态、最近握手时间、联机 IP 和隧道入口。
- 默认开启自动重连。
- 后端保留脱敏日志，便于开发排查。

插件不负责：

- 喵服登录、验证码、注册和账号管理。
- 创建房间、加入房间、读取房间人数。
- 读取浏览器 `localStorage` 或复用网页登录态。
- 在 UI 里展示长诊断日志。

## Steam Deck 使用流程

首次使用：

1. 在插件里打开喵服网页。
2. 登录喵服，下载 Windows/PC 教程里的 `.conf` 隧道文件。
3. 回到插件，点击“更新隧道配置”。
4. 点击“连接喵服”。

日常使用：

1. 打开插件。
2. 点击“连接喵服”。
3. 在喵服网页里创建或加入房间。

如果网页提示重新下载隧道文件，再回到插件点击“更新隧道配置”。

## WireGuard 内置方式

发布包会优先使用插件目录下的：

- `bin/wg`
- `bin/wg-quick`

如果这些文件不存在，后端会回退查找 SteamOS 系统路径里的 `wg` 和 `wg-quick`。正式打包脚本要求 `bin/wg` 和 `bin/wg-quick` 必须存在，并会校验 SHA256。当前后端启动环境会把插件 `bin/` 放到 `PATH` 最前面，确保内置 `wg-quick` 调用到同目录里的 `wg`。

当前版本不包含也不调用 `wireguard-go`。Steam Deck 正常情况下有内核 WireGuard 支持，实际启动以 `wg-quick` 为主。

内置 `wg` / `wg-quick` 来自 Arch Linux `wireguard-tools` x86_64 包，版本为 `1.0.20260223`，上游许可证为 GPL-2.0。来源页面：

- https://archlinux.org/packages/extra/x86_64/wireguard-tools/

当前内置文件 SHA256：

- `bin/wg`: `1E5A2936870B30CEF1A4FC74453B57C1527D7B7F619BD9DD30AA613E6D09A0EC`
- `bin/wg-quick`: `C557B7D6DC9D9CB7D29026666686CDBC6B92804D9232AC8BAE1B58FABD4DCF6D`

## 后端接口

主要 Decky callable：

- `quick_status()`
- `status()`
- `scan_configs(force=False)`
- `import_config(path)`
- `start_service()`
- `stop_service()`
- `restart_service()`
- `set_keepalive(enabled)`
- `cleanup_plugin_state(uninstall=False)`
- `nyafu_open_urls()`

保留但默认关闭的开发接口：

- `diagnostics()`
- `nyafu_save_token(token)`
- `nyafu_clear_token()`
- `nyafu_login(...)`
- `nyafu_user_info()`
- `nyafu_get_room()`
- `nyafu_get_ip()`
- `nyafu_select_node(node_alias)`

这些喵服网页/API接口只有在显式设置 `NYAFUWG_ENABLE_NYAFU_API=1` 时才会执行。默认发布形态下，账号、节点和房间操作都交给喵服网页。

## 安全默认值

- 当前配置保存到 `DECKY_PLUGIN_SETTINGS_DIR/profiles/nyafuwg0.conf`。
- 运行状态保存到 `DECKY_PLUGIN_RUNTIME_DIR/state.json`。
- 脱敏日志保存到 `DECKY_PLUGIN_LOG_DIR/nyafuwg.log`。
- 拒绝导入 `AllowedIPs = 0.0.0.0/0` 或 `::/0` 的全局代理配置，除非设置 `NYAFUWG_ALLOW_FULL_TUNNEL=1`。
- 默认期望喵服地址前缀为 `100.64.` 或 `fd`。
- 日志会隐藏 `PrivateKey`、`PresharedKey`、`Authorization`、`Bearer` 和 token 类字段。
- 卸载时可清理插件自己的配置、运行状态和日志目录。

## 构建和验证

```bash
python -m unittest discover -s tests -v
python -m py_compile main.py tests/test_backend.py scripts/package_decky.py
python scripts/package_decky.py --out NyaFuWG.zip
```

前端源码在 `src/index.tsx`。如果 Windows 环境无法执行 Node/pnpm，可以先使用仓库内的 `dist/index.js` 测试；正式发布建议在 SteamOS、Linux 或 WSL 中重新构建前端：

```bash
pnpm install
pnpm run build
python scripts/package_decky.py --out NyaFuWG.zip
```
