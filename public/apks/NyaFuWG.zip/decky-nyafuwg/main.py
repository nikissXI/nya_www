import asyncio
import copy
import hashlib
import ipaddress
import json
import os
import re
import shutil
import stat
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from collections import deque
from datetime import datetime, timezone
from pathlib import Path

try:
    import decky
except Exception:  # pragma: no cover - only used by local tests without Decky.
    class _Logger:
        def info(self, *args, **kwargs):
            pass

        def warning(self, *args, **kwargs):
            pass

        def error(self, *args, **kwargs):
            pass

    class _Decky:
        DECKY_PLUGIN_DIR = str(Path(__file__).resolve().parent)
        DECKY_PLUGIN_SETTINGS_DIR = str(Path(__file__).resolve().parent / "settings")
        DECKY_PLUGIN_RUNTIME_DIR = str(Path(__file__).resolve().parent / "runtime")
        DECKY_PLUGIN_LOG_DIR = str(Path(__file__).resolve().parent / "logs")
        DECKY_USER_HOME = str(Path.home())
        logger = _Logger()

        async def emit(self, *_args, **_kwargs):
            pass

    decky = _Decky()


PLUGIN_DIR = Path(os.environ.get("NYAFUWG_PLUGIN_DIR", decky.DECKY_PLUGIN_DIR))
SETTINGS_DIR = Path(os.environ.get("NYAFUWG_SETTINGS_DIR", decky.DECKY_PLUGIN_SETTINGS_DIR))
RUNTIME_DIR = Path(os.environ.get("NYAFUWG_RUNTIME_DIR", decky.DECKY_PLUGIN_RUNTIME_DIR))
LOG_DIR = Path(os.environ.get("NYAFUWG_LOG_DIR", decky.DECKY_PLUGIN_LOG_DIR))
DECK_HOME = Path(os.environ.get("NYAFUWG_DECK_HOME", decky.DECKY_USER_HOME))
BUNDLED_BIN_DIR = Path(os.environ.get("NYAFUWG_BUNDLED_BIN_DIR", PLUGIN_DIR / "bin"))

WG_INTERFACE = os.environ.get("NYAFUWG_INTERFACE", "nyafuwg0")
CONFIG_DIR = Path(os.environ.get("NYAFUWG_CONFIG_DIR", SETTINGS_DIR / "profiles"))
ACTIVE_CONFIG = Path(os.environ.get("NYAFUWG_ACTIVE_CONFIG", CONFIG_DIR / f"{WG_INTERFACE}.conf"))
CONFIG_META = Path(os.environ.get("NYAFUWG_CONFIG_META", CONFIG_DIR / f"{WG_INTERFACE}.json"))
STATE_FILE = Path(os.environ.get("NYAFUWG_STATE_FILE", RUNTIME_DIR / "state.json"))
LOG_FILE = Path(os.environ.get("NYAFUWG_LOG_FILE", LOG_DIR / "nyafuwg.log"))
TOKEN_FILE = Path(os.environ.get("NYAFUWG_TOKEN_FILE", SETTINGS_DIR / "nyafu_token.json"))
NYAFU_API_BASE = os.environ.get("NYAFUWG_API_BASE", "https://nyaapi.nikiss.top").rstrip("/")
NYAFU_WEB_BASE = os.environ.get("NYAFUWG_WEB_BASE", "https://nya.nikiss.top").rstrip("/")

PACKAGE_TOP_LEVEL = {
    "bin",
    "dist",
    "main.py",
    "package.json",
    "plugin.json",
    "README.md",
}
PACKAGE_BIN_FILES = {"wg", "wg-quick", "wireguard-go"}
PACKAGE_DIST_FILES = {"index.js"}
OBSOLETE_TOP_LEVEL = {
    "src",
    "tests",
    "scripts",
    "__pycache__",
    "node_modules",
    "nyafu-js",
    "nyafu-home.html",
    "pnpm-lock.yaml",
    "rollup.config.js",
    "tsconfig.json",
    ".gitignore",
}

MAX_SCAN_FILES = 300
MAX_SCAN_DEPTH = 3
MAX_CONFIG_BYTES = 512 * 1024
LOG_MAX_BYTES = 256 * 1024
LOG_BACKUPS = 3
LOG_TAIL_LINES = 40
SCAN_CACHE_TTL_SECONDS = 30
WATCHDOG_INTERVAL_SECONDS = int(os.environ.get("NYAFUWG_WATCHDOG_INTERVAL", "20"))
HANDSHAKE_STALE_SECONDS = int(os.environ.get("NYAFUWG_HANDSHAKE_STALE", "180"))

CONFIG_SUFFIXES = {".conf", ".wg", ".wireguard"}
REJECT_FULL_TUNNEL = os.environ.get("NYAFUWG_ALLOW_FULL_TUNNEL") != "1"
EXPECTED_ADDRESS_PREFIXES = tuple(
    part.strip()
    for part in os.environ.get("NYAFUWG_ADDRESS_PREFIXES", "100.64.,fd").split(",")
    if part.strip()
)
ALLOWED_ENDPOINT_RE = os.environ.get("NYAFUWG_ALLOWED_ENDPOINT_RE", "")
NYAFU_API_DISABLED_MESSAGE = "喵服网页能力默认关闭，请使用喵服网页完成账号、节点和房间操作"

IMPORT_LOCK = asyncio.Lock()
SERVICE_LOCK = asyncio.Lock()

SKIP_SCAN_DIRS = {
    ".cache",
    ".git",
    ".local",
    ".steam",
    ".var",
    "__pycache__",
    "compatdata",
    "node_modules",
    "shadercache",
}


def _import_roots() -> tuple[Path, ...]:
    configured = os.environ.get("NYAFUWG_IMPORT_ROOTS")
    if configured:
        return tuple(Path(part) for part in configured.split(os.pathsep) if part)
    return (
        DECK_HOME / "Downloads",
        DECK_HOME / "downloads",
        DECK_HOME / "下载",
        DECK_HOME / "Documents",
        DECK_HOME / "文档",
        DECK_HOME / "Desktop",
        DECK_HOME / "桌面",
        Path("/run/media/deck"),
        Path("/run/media/mmcblk0p1"),
    )


IMPORT_ROOTS = _import_roots()


def _clean_env() -> dict:
    env = os.environ.copy()
    for key in ("LD_LIBRARY_PATH", "LD_PRELOAD", "STEAM_RUNTIME", "PRESSURE_VESSEL_RUNTIME"):
        env.pop(key, None)
    env["PATH"] = f"{BUNDLED_BIN_DIR}:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
    return env


def _sanitize_output(text: str, limit: int = 1200) -> str:
    redacted = []
    secret_patterns = (
        r"(?i)(PrivateKey\s*=\s*)\S+",
        r"(?i)(PresharedKey\s*=\s*)\S+",
        r"(?i)(private_key['\"]?\s*[:=]\s*['\"]?)\S+",
        r"(?i)(Authorization\s*[:=]\s*Bearer\s+)\S+",
        r"(?i)(Bearer\s+)[A-Za-z0-9._~+/=-]+",
        r"(?i)(token['\"]?\s*[:=]\s*['\"]?)[A-Za-z0-9._~+/=-]+",
    )
    for line in (text or "").splitlines():
        safe = line.strip()
        for pattern in secret_patterns:
            safe = re.sub(pattern, r"\1<redacted>", safe)
        redacted.append(safe)
    return "\n".join(redacted).strip()[:limit]


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Plugin:
    def __init__(self):
        self._scan_cache = None
        self._scan_cache_at = 0.0
        self._last_error = None
        self._watchdog_task = None
        self._last_service = None

    def _set_last_error(self, code: str, message: str, details: str = "") -> dict:
        error = {
            "code": code,
            "message": message,
            "details": _sanitize_output(details),
            "at": _now_iso(),
        }
        self._last_error = error
        return error

    def _error_result(self, code: str, message: str, details: str = "", status: dict | None = None) -> dict:
        error = self._set_last_error(code, message, details)
        return {
            "ok": False,
            "code": code,
            "message": message,
            "details": error["details"],
            "status": status,
        }

    def _state(self) -> dict:
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {"desired_connected": False, "keepalive": True}

    def _write_state(self, **updates) -> dict:
        state = self._state()
        state.update(updates)
        state["updated_at"] = _now_iso()
        RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
        return state

    def _upgrade_cleanup_enabled(self) -> bool:
        if os.environ.get("NYAFUWG_DISABLE_UPGRADE_CLEANUP") == "1":
            return False
        if os.environ.get("NYAFUWG_TEST_UPGRADE_CLEANUP") == "1":
            return True
        return True

    def _remove_tree_or_file(self, path: Path) -> None:
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
        else:
            path.unlink(missing_ok=True)

    def _cleanup_upgrade_artifacts(self) -> None:
        if not self._upgrade_cleanup_enabled() or not PLUGIN_DIR.exists():
            return

        for child in PLUGIN_DIR.iterdir():
            should_remove = child.name in OBSOLETE_TOP_LEVEL
            if child.name.endswith((".zip", ".map", ".pyc")):
                should_remove = True
            if child.name not in PACKAGE_TOP_LEVEL and should_remove:
                try:
                    self._remove_tree_or_file(child)
                except Exception as exc:
                    decky.logger.warning(f"NyaFuWG could not remove obsolete artifact path={child}: {exc}")

        for directory, allowed in ((BUNDLED_BIN_DIR, PACKAGE_BIN_FILES), (PLUGIN_DIR / "dist", PACKAGE_DIST_FILES)):
            if not directory.exists():
                continue
            for child in directory.iterdir():
                if child.name not in allowed:
                    try:
                        self._remove_tree_or_file(child)
                    except Exception as exc:
                        decky.logger.warning(f"NyaFuWG could not remove obsolete artifact path={child}: {exc}")

    def _safe_remove_owned_dir(self, path: Path) -> None:
        try:
            resolved = path.resolve()
            allowed_roots = [
                SETTINGS_DIR.resolve(),
                RUNTIME_DIR.resolve(),
                LOG_DIR.resolve(),
            ]
            if resolved not in allowed_roots:
                return
            if path.exists():
                shutil.rmtree(path)
        except Exception as exc:
            decky.logger.warning(f"NyaFuWG could not remove owned dir path={path}: {exc}")

    def _log_line(self, line: str) -> None:
        safe = _sanitize_output(line, limit=2000)
        if not safe:
            return
        try:
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            if LOG_FILE.exists() and LOG_FILE.stat().st_size >= LOG_MAX_BYTES:
                for index in range(LOG_BACKUPS, 0, -1):
                    src = LOG_FILE.with_name(f"{LOG_FILE.name}.{index}")
                    dst = LOG_FILE.with_name(f"{LOG_FILE.name}.{index + 1}")
                    if index == LOG_BACKUPS:
                        src.unlink(missing_ok=True)
                    elif src.exists():
                        src.replace(dst)
                LOG_FILE.replace(LOG_FILE.with_name(f"{LOG_FILE.name}.1"))
            with LOG_FILE.open("a", encoding="utf-8") as handle:
                handle.write(f"{_now_iso()} {safe}\n")
        except Exception as exc:
            decky.logger.warning(f"NyaFuWG could not write log: {exc}")

    def _recent_log(self, limit: int = LOG_TAIL_LINES) -> list[str]:
        try:
            if not LOG_FILE.exists():
                return []
            lines = LOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception as exc:
            decky.logger.warning(f"NyaFuWG could not read log: {exc}")
            return []
        return [_sanitize_output(line, limit=2000) for line in lines[-limit:] if _sanitize_output(line)]

    def _read_token(self) -> str:
        try:
            data = json.loads(TOKEN_FILE.read_text(encoding="utf-8"))
            return str(data.get("token", "")).strip()
        except Exception:
            return ""

    def _write_token(self, token: str) -> None:
        SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
        TOKEN_FILE.write_text(
            json.dumps({"token": token.strip(), "saved_at": _now_iso()}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        try:
            TOKEN_FILE.chmod(0o600)
        except Exception:
            pass

    def _http_json_sync(
        self,
        path: str,
        *,
        method: str = "GET",
        token: str | None = None,
        body: dict | None = None,
        query: dict | None = None,
        timeout: int = 15,
    ) -> dict:
        url = f"{NYAFU_API_BASE}{path}"
        if query:
            url = f"{url}?{urllib.parse.urlencode(query)}"
        headers = {
            "Accept": "application/json",
            "User-Agent": "NyaFuWG-Decky/0.1",
        }
        payload = None
        if body is not None:
            headers["Content-Type"] = "application/json"
            payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
        if token:
            headers["Authorization"] = f"Bearer {token}"
        request = urllib.request.Request(url, data=payload, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                text = response.read().decode("utf-8", errors="replace")
                return {"ok": True, "status": response.status, "data": json.loads(text) if text else None}
        except urllib.error.HTTPError as exc:
            text = exc.read().decode("utf-8", errors="replace")
            data = None
            try:
                data = json.loads(text) if text else None
            except Exception:
                data = text
            return {"ok": False, "status": exc.code, "data": data, "error": str(exc)}
        except Exception as exc:
            return {"ok": False, "status": 0, "data": None, "error": str(exc)}

    async def _http_json(self, *args, **kwargs) -> dict:
        return await asyncio.to_thread(self._http_json_sync, *args, **kwargs)

    def _api_result(self, response: dict, default_error: str = "喵服接口请求失败") -> dict:
        data = response.get("data")
        if response.get("ok"):
            return {"ok": True, "status_code": response.get("status"), "data": data}
        msg = default_error
        if isinstance(data, dict):
            msg = data.get("msg") or data.get("message") or msg
        elif isinstance(data, str) and data:
            msg = data[:160]
        self._set_last_error("nyafu_api_failed", msg, response.get("error", ""))
        return {"ok": False, "status_code": response.get("status"), "message": msg, "data": data}

    def _nyafu_api_enabled(self) -> bool:
        return os.environ.get("NYAFUWG_ENABLE_NYAFU_API") == "1"

    def _nyafu_api_disabled_result(self) -> dict:
        return {"ok": False, "code": "nyafu_api_disabled", "message": NYAFU_API_DISABLED_MESSAGE}

    async def nyafu_save_token(self, token: str) -> dict:
        if not self._nyafu_api_enabled():
            return self._nyafu_api_disabled_result()
        token = (token or "").strip()
        if not token:
            return {"ok": False, "message": "Token 不能为空"}
        self._write_token(token)
        return {"ok": True, "message": "喵服登录凭证已保存"}

    async def nyafu_clear_token(self) -> dict:
        if not self._nyafu_api_enabled():
            return self._nyafu_api_disabled_result()
        TOKEN_FILE.unlink(missing_ok=True)
        return {"ok": True, "message": "喵服登录凭证已清除"}

    async def nyafu_login(self, verify_type: str, account: str, password_sha256: str, uuid_value: str, captcha_code: str) -> dict:
        if not self._nyafu_api_enabled():
            return self._nyafu_api_disabled_result()
        body = {
            "verifyType": verify_type,
            "account": account,
            "password": password_sha256,
            "uuid": uuid_value,
            "captcha_code": captcha_code.lower(),
        }
        response = await self._http_json("/login", method="POST", body=body)
        result = self._api_result(response, "登录失败")
        data = result.get("data")
        if result.get("ok") and isinstance(data, dict) and data.get("code") == 0 and data.get("token"):
            self._write_token(data["token"])
            return {"ok": True, "message": "登录成功"}
        if isinstance(data, dict):
            return {"ok": False, "message": data.get("msg") or "登录失败", "data": data}
        return result

    async def nyafu_password_sha256(self, password: str) -> str:
        if not self._nyafu_api_enabled():
            return ""
        return hashlib.sha256((password or "").encode("utf-8")).hexdigest()

    async def nyafu_server_data(self) -> dict:
        if not self._nyafu_api_enabled():
            return self._nyafu_api_disabled_result()
        return self._api_result(await self._http_json("/serverData"), "获取喵服服务信息失败")

    async def nyafu_node_list(self) -> dict:
        if not self._nyafu_api_enabled():
            return self._nyafu_api_disabled_result()
        return self._api_result(await self._http_json("/nodeList"), "获取节点列表失败")

    async def nyafu_user_info(self) -> dict:
        if not self._nyafu_api_enabled():
            return self._nyafu_api_disabled_result()
        token = self._read_token()
        if not token:
            return {"ok": False, "message": "未保存喵服登录凭证"}
        return self._api_result(await self._http_json("/userInfo", token=token), "获取用户信息失败")

    async def nyafu_get_room(self) -> dict:
        if not self._nyafu_api_enabled():
            return self._nyafu_api_disabled_result()
        token = self._read_token()
        if not token:
            return {"ok": False, "message": "未保存喵服登录凭证"}
        return self._api_result(await self._http_json("/getRoom", token=token), "获取房间信息失败")

    async def nyafu_get_ip(self) -> dict:
        if not self._nyafu_api_enabled():
            return self._nyafu_api_disabled_result()
        token = self._read_token()
        if not token:
            return {"ok": False, "message": "未保存喵服登录凭证"}
        result = self._api_result(await self._http_json("/getIp", token=token), "获取 WireGuard 隧道失败")
        data = result.get("data")
        if result.get("ok") and isinstance(data, dict) and data.get("code") == 0:
            wg_data = data.get("wg_data") or {}
            conf_text = wg_data.get("conf_text")
            if conf_text:
                imported = await self.import_config_text(conf_text, source="nyafu:/getIp")
                result["import_result"] = imported
        return result

    async def nyafu_select_node(self, node_alias: str = "") -> dict:
        if not self._nyafu_api_enabled():
            return self._nyafu_api_disabled_result()
        token = self._read_token()
        if not token:
            return {"ok": False, "message": "未保存喵服登录凭证"}
        query = {"node_alias": node_alias} if node_alias else None
        result = self._api_result(await self._http_json("/selectNode", token=token, query=query), "切换节点失败")
        data = result.get("data")
        if result.get("ok") and isinstance(data, dict):
            conf_text = data.get("conf_text")
            if conf_text:
                result["import_result"] = await self.import_config_text(conf_text, source=f"nyafu:/selectNode/{node_alias}")
        return result

    async def nyafu_get_download_conf_key(self) -> dict:
        if not self._nyafu_api_enabled():
            return self._nyafu_api_disabled_result()
        token = self._read_token()
        if not token:
            return {"ok": False, "message": "未保存喵服登录凭证"}
        return self._api_result(await self._http_json("/getDownloadConfkey", token=token), "获取配置下载密钥失败")

    async def nyafu_open_urls(self) -> dict:
        return {
            "ok": True,
            "web_base": NYAFU_WEB_BASE,
            "login": f"{NYAFU_WEB_BASE}/me",
            "rooms": f"{NYAFU_WEB_BASE}/room",
            "docs": f"{NYAFU_WEB_BASE}/docs#download",
        }

    def _candidate_tools(self, name: str) -> tuple[Path, ...]:
        override = os.environ.get(f"NYAFUWG_{name.upper().replace('-', '_')}")
        paths = []
        if override:
            paths.append(Path(override))
        paths.extend(
            [
                BUNDLED_BIN_DIR / name,
                Path("/usr/bin") / name,
                Path("/usr/local/bin") / name,
                Path("/bin") / name,
                Path("/sbin") / name,
            ]
        )
        return tuple(paths)

    def _tool(self, name: str) -> Path | None:
        for path in self._candidate_tools(name):
            if path.exists():
                try:
                    if path.is_file() and not os.access(path, os.X_OK):
                        path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
                except Exception:
                    pass
                return path
        return None

    def _tools(self) -> dict:
        return {
            "wg": self._tool("wg"),
            "wg_quick": self._tool("wg-quick"),
            "ip": self._tool("ip"),
        }

    async def _run(self, args, timeout: int = 20, log_failure: bool = True) -> dict:
        try:
            proc = await asyncio.create_subprocess_exec(
                *[str(arg) for arg in args],
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=_clean_env(),
            )
        except Exception as exc:
            if log_failure:
                decky.logger.warning(f"NyaFuWG command start failed args={args!r}: {exc}")
            return {"ok": False, "code": 127, "stdout": "", "stderr": str(exc)}

        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            if log_failure:
                decky.logger.warning(f"NyaFuWG command timed out timeout={timeout}s args={args!r}")
            return {"ok": False, "code": 124, "stdout": "", "stderr": "command timed out"}

        stdout_text = stdout.decode("utf-8", errors="replace")
        stderr_text = stderr.decode("utf-8", errors="replace")
        if proc.returncode != 0 and log_failure:
            decky.logger.warning(
                f"NyaFuWG command failed code={proc.returncode} args={args!r} stderr={_sanitize_output(stderr_text)!r}"
            )
        if stdout_text.strip():
            self._log_line(stdout_text)
        if stderr_text.strip():
            self._log_line(stderr_text)
        return {"ok": proc.returncode == 0, "code": proc.returncode, "stdout": stdout_text, "stderr": stderr_text}

    async def _run_root(self, args, timeout: int = 20, log_failure: bool = True) -> dict:
        if getattr(os, "geteuid", lambda: 1)() != 0:
            return {
                "ok": False,
                "code": 126,
                "stdout": "",
                "stderr": "插件没有 root 权限。请确认 plugin.json 包含 root flag，并重启 Decky Loader。",
            }
        return await self._run(args, timeout=timeout, log_failure=log_failure)

    def _parse_wg_config(self, text: str) -> dict:
        section = ""
        data: dict[str, list[dict[str, str]]] = {"Interface": [], "Peer": []}
        current: dict[str, str] | None = None
        for raw_line in text.splitlines():
            line = raw_line.split("#", 1)[0].split(";", 1)[0].strip()
            if not line:
                continue
            match = re.match(r"^\[([A-Za-z]+)\]$", line)
            if match:
                section = match.group(1)
                current = {}
                data.setdefault(section, []).append(current)
                continue
            if "=" in line and current is not None:
                key, value = line.split("=", 1)
                current[key.strip()] = value.strip()
        return data

    def _config_summary_from_text(self, text: str) -> dict:
        parsed = self._parse_wg_config(text)
        interface = parsed.get("Interface", [{}])[0] if parsed.get("Interface") else {}
        peers = parsed.get("Peer", [])
        addresses = [part.strip() for part in interface.get("Address", "").split(",") if part.strip()]
        allowed_ips = []
        endpoints = []
        for peer in peers:
            allowed_ips.extend(part.strip() for part in peer.get("AllowedIPs", "").split(",") if part.strip())
            if peer.get("Endpoint"):
                endpoints.append(peer["Endpoint"])
        return {
            "exists": True,
            "interface": WG_INTERFACE,
            "addresses": addresses,
            "dns": interface.get("DNS", ""),
            "peer_count": len(peers),
            "endpoints": endpoints,
            "allowed_ips": allowed_ips,
            "private_key_set": bool(interface.get("PrivateKey")),
        }

    def _current_config_summary(self) -> dict:
        if not ACTIVE_CONFIG.exists():
            return {"exists": False}
        try:
            return self._config_summary_from_text(ACTIVE_CONFIG.read_text(encoding="utf-8", errors="replace"))
        except Exception as exc:
            return {"exists": True, "error": str(exc)}

    def _parse_interface_addresses(self, addresses: list[str]) -> tuple[list[object], list[str]]:
        parsed = []
        bad = []
        for address in addresses:
            try:
                parsed.append(ipaddress.ip_interface(address))
            except ValueError:
                bad.append(address)
        return parsed, bad

    def _parse_allowed_networks(self, allowed_ips: list[str]) -> tuple[list[object], list[str]]:
        parsed = []
        bad = []
        for value in allowed_ips:
            try:
                parsed.append(ipaddress.ip_network(value, strict=False))
            except ValueError:
                bad.append(value)
        return parsed, bad

    def _validate_config_text(self, text: str) -> dict:
        if len(text.encode("utf-8", errors="ignore")) > MAX_CONFIG_BYTES:
            return {"ok": False, "code": "config_too_large", "message": "配置文件过大"}
        parsed = self._parse_wg_config(text)
        interfaces = parsed.get("Interface", [])
        peers = parsed.get("Peer", [])
        if len(interfaces) != 1:
            return {"ok": False, "code": "invalid_config", "message": "WireGuard 配置必须包含一个 [Interface]"}
        if not peers:
            return {"ok": False, "code": "invalid_config", "message": "WireGuard 配置必须包含至少一个 [Peer]"}
        interface = interfaces[0]
        for key in ("PrivateKey", "Address"):
            if not interface.get(key):
                return {"ok": False, "code": "invalid_config", "message": f"配置缺少 Interface.{key}"}
        for index, peer in enumerate(peers, start=1):
            for key in ("PublicKey", "AllowedIPs"):
                if not peer.get(key):
                    return {"ok": False, "code": "invalid_config", "message": f"第 {index} 个 Peer 缺少 {key}"}

        summary = self._config_summary_from_text(text)
        parsed_addresses, bad_addresses = self._parse_interface_addresses(summary["addresses"])
        if bad_addresses:
            return {
                "ok": False,
                "code": "invalid_address",
                "message": "配置包含无效的 Interface.Address",
                "details": ", ".join(bad_addresses),
            }
        parsed_allowed, bad_allowed = self._parse_allowed_networks(summary["allowed_ips"])
        if bad_allowed:
            return {
                "ok": False,
                "code": "invalid_allowed_ips",
                "message": "配置包含无效的 Peer.AllowedIPs",
                "details": ", ".join(bad_allowed),
            }
        if EXPECTED_ADDRESS_PREFIXES:
            matching = [
                str(address)
                for address in parsed_addresses
                if any(str(address).startswith(prefix) for prefix in EXPECTED_ADDRESS_PREFIXES)
            ]
            if not matching:
                return {
                    "ok": False,
                    "code": "unexpected_address",
                    "message": "配置不像喵服联机地址",
                    "details": f"Address 应以 {', '.join(EXPECTED_ADDRESS_PREFIXES)} 开头",
                }
        if REJECT_FULL_TUNNEL:
            found = [str(network) for network in parsed_allowed if network.prefixlen == 0]
            if found:
                return {
                    "ok": False,
                    "code": "full_tunnel_rejected",
                    "message": "拒绝导入全局代理配置",
                    "details": f"AllowedIPs 包含 {', '.join(found)}",
                }
        if ALLOWED_ENDPOINT_RE:
            regex = re.compile(ALLOWED_ENDPOINT_RE)
            bad = [endpoint for endpoint in summary["endpoints"] if not regex.search(endpoint)]
            if bad:
                return {
                    "ok": False,
                    "code": "unexpected_endpoint",
                    "message": "Endpoint 不在允许范围内",
                    "details": ", ".join(bad),
                }
        return {"ok": True, "message": "配置有效", "summary": summary}

    def _scan_candidate(self, path: Path, current: bool = False) -> dict | None:
        if not path.is_file() or path.suffix.lower() not in CONFIG_SUFFIXES:
            return None
        try:
            stat_result = path.stat()
            if stat_result.st_size <= 0 or stat_result.st_size > MAX_CONFIG_BYTES:
                return None
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return None
        check = self._validate_config_text(text)
        if not check.get("ok"):
            return None
        summary = check.get("summary", {})
        name = path.stem
        if summary.get("endpoints"):
            name = f"{path.stem} · {summary['endpoints'][0].split(':')[0]}"
        return {
            "path": str(path),
            "name": name,
            "size": stat_result.st_size,
            "mtime": int(stat_result.st_mtime),
            "current": current,
            "source": "current" if current else "import",
            "addresses": summary.get("addresses", []),
            "endpoints": summary.get("endpoints", []),
            "allowed_ips": summary.get("allowed_ips", []),
        }

    def _iter_config_files(self, root: Path):
        try:
            if root.is_file():
                if root.suffix.lower() in CONFIG_SUFFIXES:
                    yield root
                return
            if not root.is_dir():
                return
        except Exception:
            return

        queue = deque([(root, 0)])
        seen_dirs = set()
        while queue:
            directory, depth = queue.popleft()
            try:
                resolved = directory.resolve()
            except Exception:
                continue
            if resolved in seen_dirs:
                continue
            seen_dirs.add(resolved)
            try:
                entries = sorted(directory.iterdir(), key=lambda item: (not item.is_file(), item.name.lower()))
            except Exception:
                continue
            for entry in entries:
                try:
                    if entry.is_file() and entry.suffix.lower() in CONFIG_SUFFIXES:
                        yield entry
                    elif depth < MAX_SCAN_DEPTH and entry.is_dir() and entry.name not in SKIP_SCAN_DIRS:
                        queue.append((entry, depth + 1))
                except Exception:
                    continue

    def _is_allowed_import_path(self, path: Path) -> bool:
        try:
            resolved = path.resolve()
        except Exception:
            return False
        for root in IMPORT_ROOTS:
            try:
                root_resolved = root.resolve()
                if resolved == root_resolved or root_resolved in resolved.parents:
                    return True
            except Exception:
                continue
        return False

    def _is_current_config_path(self, path: Path) -> bool:
        try:
            return path.resolve() == ACTIVE_CONFIG.resolve()
        except Exception:
            return False

    def _cache_scan_result(self, result: dict) -> dict:
        self._scan_cache = copy.deepcopy(result)
        self._scan_cache_at = time.monotonic()
        return result

    def _invalidate_scan_cache(self) -> None:
        self._scan_cache = None
        self._scan_cache_at = 0.0

    async def scan_configs(self, force: bool = False) -> dict:
        if not force and self._scan_cache and time.monotonic() - self._scan_cache_at < SCAN_CACHE_TTL_SECONDS:
            cached = copy.deepcopy(self._scan_cache)
            cached["cached"] = True
            return cached

        candidates = []
        seen = set()
        scanned = 0
        current = self._scan_candidate(ACTIVE_CONFIG, current=True) if ACTIVE_CONFIG.exists() else None
        if current:
            candidates.append(current)
            seen.add(str(ACTIVE_CONFIG.resolve()))

        for root in IMPORT_ROOTS:
            if not root.exists():
                continue
            for path in self._iter_config_files(root):
                scanned += 1
                if scanned > MAX_SCAN_FILES or len(candidates) >= 30:
                    break
                try:
                    key = str(path.resolve())
                except Exception:
                    key = str(path)
                if key in seen:
                    continue
                seen.add(key)
                candidate = self._scan_candidate(path)
                if candidate:
                    candidates.append(candidate)
            if scanned > MAX_SCAN_FILES or len(candidates) >= 30:
                break
        candidates.sort(key=lambda item: (not item.get("current"), -item.get("mtime", 0), item["name"].lower()))
        return self._cache_scan_result(
            {"ok": True, "configs": candidates, "scanned": scanned, "roots": [str(root) for root in IMPORT_ROOTS], "cached": False}
        )

    async def import_config(self, path: str) -> dict:
        async with IMPORT_LOCK:
            tmp = None
            try:
                src = Path(path)
                if not src.exists() or not src.is_file():
                    return {"ok": False, "message": "配置文件不存在", "status": await self.quick_status()}
                if self._is_current_config_path(src):
                    return {"ok": True, "message": "已是当前配置", "status": await self.quick_status()}
                if not self._is_allowed_import_path(src):
                    return {"ok": False, "message": "只能导入下载、文档、桌面或外接盘中的配置", "status": await self.quick_status()}

                CONFIG_DIR.mkdir(parents=True, exist_ok=True)
                tmp = CONFIG_DIR / f"import-check-{uuid.uuid4().hex}.conf"
                shutil.copyfile(src, tmp)
                text = tmp.read_text(encoding="utf-8", errors="replace")
                check = self._validate_config_text(text)
                if not check.get("ok"):
                    self._set_last_error(check.get("code", "invalid_config"), check.get("message", "配置无效"), check.get("details", ""))
                    return {
                        "ok": False,
                        "code": check.get("code", "invalid_config"),
                        "message": check.get("message", "配置无效"),
                        "details": check.get("details", ""),
                        "status": await self.quick_status(),
                    }

                backup = None
                if ACTIVE_CONFIG.exists():
                    backup = ACTIVE_CONFIG.with_suffix(".conf.bak")
                    shutil.copyfile(ACTIVE_CONFIG, backup)
                os.replace(tmp, ACTIVE_CONFIG)
                tmp = None
                ACTIVE_CONFIG.chmod(0o600)
                meta = {
                    "source": str(src),
                    "imported_at": _now_iso(),
                    "backup": str(backup) if backup else "",
                    "summary": check.get("summary", {}),
                }
                CONFIG_META.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
                self._invalidate_scan_cache()
                return {
                    "ok": True,
                    "message": "配置已导入",
                    "status": await self.quick_status(),
                    "current_config": self._scan_candidate(ACTIVE_CONFIG, current=True),
                }
            except Exception as exc:
                decky.logger.error(f"NyaFuWG import config failed path={path!r}: {exc}")
                return self._error_result("import_failed", f"导入失败：{exc}", str(exc), await self.quick_status())
            finally:
                if tmp:
                    tmp.unlink(missing_ok=True)

    async def import_config_text(self, text: str, source: str = "nyafu-api") -> dict:
        async with IMPORT_LOCK:
            tmp = None
            try:
                CONFIG_DIR.mkdir(parents=True, exist_ok=True)
                tmp = CONFIG_DIR / f"api-import-{uuid.uuid4().hex}.conf"
                tmp.write_text(text or "", encoding="utf-8")
                check = self._validate_config_text(tmp.read_text(encoding="utf-8", errors="replace"))
                if not check.get("ok"):
                    self._set_last_error(check.get("code", "invalid_config"), check.get("message", "配置无效"), check.get("details", ""))
                    return {
                        "ok": False,
                        "code": check.get("code", "invalid_config"),
                        "message": check.get("message", "配置无效"),
                        "details": check.get("details", ""),
                        "status": await self.quick_status(),
                    }
                backup = None
                if ACTIVE_CONFIG.exists():
                    backup = ACTIVE_CONFIG.with_suffix(".conf.bak")
                    shutil.copyfile(ACTIVE_CONFIG, backup)
                os.replace(tmp, ACTIVE_CONFIG)
                tmp = None
                ACTIVE_CONFIG.chmod(0o600)
                CONFIG_META.write_text(
                    json.dumps(
                        {
                            "source": source,
                            "imported_at": _now_iso(),
                            "backup": str(backup) if backup else "",
                            "summary": check.get("summary", {}),
                        },
                        ensure_ascii=False,
                        indent=2,
                    ),
                    encoding="utf-8",
                )
                self._invalidate_scan_cache()
                return {"ok": True, "message": "配置已导入", "status": await self.quick_status()}
            finally:
                if tmp:
                    tmp.unlink(missing_ok=True)

    async def restore_backup_config(self) -> dict:
        backup = ACTIVE_CONFIG.with_suffix(".conf.bak")
        if not backup.exists():
            return {"ok": False, "message": "没有可恢复的备份", "status": await self.quick_status()}
        async with IMPORT_LOCK:
            shutil.copyfile(backup, ACTIVE_CONFIG)
            ACTIVE_CONFIG.chmod(0o600)
            self._invalidate_scan_cache()
            return {"ok": True, "message": "已恢复上一份配置", "status": await self.quick_status()}

    async def _wg_show_dump(self) -> str:
        wg = self._tool("wg")
        if not wg:
            return ""
        result = await self._run([wg, "show", WG_INTERFACE, "dump"], timeout=5, log_failure=False)
        if not result.get("ok"):
            return ""
        return result.get("stdout", "")

    def _parse_wg_dump(self, dump: str) -> dict:
        lines = [line.split("\t") for line in (dump or "").splitlines() if line.strip()]
        if not lines:
            return {}
        peers = []
        now = int(time.time())
        for row in lines[1:]:
            if len(row) < 8:
                continue
            latest = int(row[4]) if row[4].isdigit() else 0
            peers.append(
                {
                    "public_key": row[0][:8] + "..." if row[0] else "",
                    "endpoint": row[2],
                    "allowed_ips": row[3],
                    "latest_handshake": latest,
                    "handshake_age": now - latest if latest else None,
                    "rx_bytes": int(row[5]) if row[5].isdigit() else 0,
                    "tx_bytes": int(row[6]) if row[6].isdigit() else 0,
                    "persistent_keepalive": row[7],
                }
            )
        return {"interface": WG_INTERFACE, "peers": peers}

    async def _interface_exists(self) -> bool:
        ip = self._tool("ip")
        if not ip:
            return bool(await self._wg_show_dump())
        result = await self._run([ip, "link", "show", "dev", WG_INTERFACE], timeout=5, log_failure=False)
        return bool(result.get("ok"))

    async def _service_state(self) -> str:
        if not await self._interface_exists():
            return "inactive"
        dump = await self._wg_show_dump()
        parsed = self._parse_wg_dump(dump)
        peers = parsed.get("peers", [])
        if peers and any(peer.get("latest_handshake") for peer in peers):
            stale = all((peer.get("handshake_age") or 999999) > HANDSHAKE_STALE_SECONDS for peer in peers)
            return "stale" if stale else "active"
        return "up"

    async def quick_status(self) -> dict:
        tools = self._tools()
        return {
            "service": await self._service_state(),
            "installed": bool(tools["wg"] and tools["wg_quick"]),
            "interface": WG_INTERFACE,
            "config": self._current_config_summary(),
            "state": self._state(),
            "quick": True,
        }

    async def status(self) -> dict:
        base = await self.quick_status()
        dump = await self._wg_show_dump()
        base["wireguard"] = self._parse_wg_dump(dump)
        base["quick"] = False
        return base

    async def diagnostics(self) -> dict:
        tools = self._tools()
        versions = {}
        for key, path in tools.items():
            if not path:
                versions[key] = ""
                continue
            version_arg = "-v" if key == "ip" else "--version"
            result = await self._run([path, version_arg], timeout=4, log_failure=False)
            versions[key] = _sanitize_output(result.get("stdout") or result.get("stderr"), limit=160).splitlines()[0] if result.get("ok") else ""
        cached_scan = copy.deepcopy(self._scan_cache) if self._scan_cache else {}
        status = await self.status()
        return {
            "ok": True,
            **status,
            "tools": {key: str(path) if path else "" for key, path in tools.items()},
            "versions": versions,
            "scan": {
                "roots": [str(root) for root in IMPORT_ROOTS],
                "suffixes": sorted(CONFIG_SUFFIXES),
                "max_bytes": MAX_CONFIG_BYTES,
                "max_depth": MAX_SCAN_DEPTH,
                "last_scanned": cached_scan.get("scanned"),
                "last_count": len(cached_scan.get("configs", [])) if cached_scan else None,
                "cached": bool(cached_scan),
            },
            "last_error": self._last_error,
            "recent_log": self._recent_log(),
        }

    async def ensure_environment(self) -> dict:
        tools = self._tools()
        if not tools["wg"]:
            return {"ok": False, "message": "未找到 wg 工具"}
        if not tools["wg_quick"]:
            return {"ok": False, "message": "未找到 wg-quick 工具"}
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        return {"ok": True, "message": "运行环境已准备"}

    async def start_service(self) -> dict:
        async with SERVICE_LOCK:
            if not ACTIVE_CONFIG.exists():
                return {"ok": False, "message": "请先导入喵服 WireGuard 配置", "status": await self.quick_status()}
            env_ready = await self.ensure_environment()
            if not env_ready.get("ok"):
                return {"ok": False, "message": env_ready.get("message") or "运行环境准备失败", "status": await self.quick_status()}
            state = await self._service_state()
            if state in ("active", "up", "stale"):
                self._write_state(desired_connected=True)
                return {"ok": True, "message": "WireGuard 已在运行", "status": await self.status()}
            wg_quick = self._tool("wg-quick")
            result = await self._run_root([wg_quick, "up", ACTIVE_CONFIG], timeout=20)
            if not result.get("ok"):
                return self._error_result(
                    "wg_up_failed",
                    "WireGuard 启动失败",
                    result.get("stderr") or result.get("stdout"),
                    await self.quick_status(),
                )
            self._write_state(desired_connected=True, last_started_at=_now_iso())
            await self._emit_status_changed()
            return {"ok": True, "message": "WireGuard 已连接", "status": await self.status()}

    async def stop_service(self) -> dict:
        async with SERVICE_LOCK:
            wg_quick = self._tool("wg-quick")
            if not wg_quick:
                self._write_state(desired_connected=False)
                return {"ok": True, "message": "WireGuard 已停止", "status": await self.quick_status()}
            if await self._interface_exists():
                result = await self._run_root([wg_quick, "down", ACTIVE_CONFIG], timeout=20, log_failure=False)
                if not result.get("ok"):
                    return self._error_result(
                        "wg_down_failed",
                        "WireGuard 停止失败",
                        result.get("stderr") or result.get("stdout"),
                        await self.quick_status(),
                    )
            self._write_state(desired_connected=False, last_stopped_at=_now_iso())
            await self._emit_status_changed()
            status = await self.quick_status()
            status["service"] = "inactive"
            return {"ok": True, "message": "WireGuard 已断开", "status": status}

    async def restart_service(self) -> dict:
        stop_result = await self.stop_service()
        if not stop_result.get("ok"):
            return stop_result
        return await self.start_service()

    async def set_keepalive(self, enabled: bool) -> dict:
        self._write_state(keepalive=bool(enabled))
        return {"ok": True, "message": "已更新守护设置", "status": await self.quick_status()}

    async def _cleanup_plugin_state(self, uninstall: bool = False) -> dict:
        await self.stop_service()
        for path in (
            ACTIVE_CONFIG,
            ACTIVE_CONFIG.with_suffix(".conf.bak"),
            CONFIG_META,
            STATE_FILE,
            TOKEN_FILE,
            LOG_FILE,
            *(LOG_FILE.with_name(f"{LOG_FILE.name}.{index}") for index in range(1, LOG_BACKUPS + 1)),
        ):
            try:
                path.unlink(missing_ok=True)
            except Exception as exc:
                decky.logger.warning(f"NyaFuWG cleanup could not remove path={path}: {exc}")
        if uninstall:
            self._safe_remove_owned_dir(SETTINGS_DIR)
            self._safe_remove_owned_dir(RUNTIME_DIR)
            self._safe_remove_owned_dir(LOG_DIR)
        return {"ok": True, "message": "插件状态已清理", "status": await self.quick_status()}

    async def cleanup_plugin_state(self, uninstall: bool = False) -> dict:
        if uninstall:
            return {"ok": False, "code": "cleanup_uninstall_disabled", "message": "彻底清理只在插件卸载流程中执行"}
        return await self._cleanup_plugin_state(uninstall=False)

    async def _emit_status_changed(self) -> None:
        try:
            await decky.emit("nyafuwg_status_changed", await self.quick_status())
        except Exception:
            pass

    async def _watchdog_loop(self) -> None:
        while True:
            try:
                await asyncio.sleep(WATCHDOG_INTERVAL_SECONDS)
                state = self._state()
                if not state.get("keepalive", True) or not state.get("desired_connected"):
                    continue
                service = await self._service_state()
                if service == "inactive":
                    self._log_line("watchdog: interface inactive, restarting")
                    await self.start_service()
                if service != self._last_service:
                    self._last_service = service
                    await self._emit_status_changed()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self._set_last_error("watchdog_failed", "连接守护异常", str(exc))
                decky.logger.warning(f"NyaFuWG watchdog failed: {exc}")

    async def _main(self):
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        self._cleanup_upgrade_artifacts()
        self._watchdog_task = asyncio.create_task(self._watchdog_loop())
        decky.logger.info("NyaFuWG backend loaded")

    async def _unload(self):
        if self._watchdog_task and not self._watchdog_task.done():
            self._watchdog_task.cancel()
        if os.environ.get("NYAFUWG_STOP_ON_UNLOAD") == "1":
            await self.stop_service()
        decky.logger.info("NyaFuWG backend unloaded")

    async def _uninstall(self):
        await self._cleanup_plugin_state(uninstall=True)
        decky.logger.info("NyaFuWG backend uninstalled")
